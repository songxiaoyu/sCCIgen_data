#' STsimulator Package
#'
#' STsimulator: a high-fidelity spatial transcriptomics data simulator
#'
#'
#' @docType package
#'
#' @author Xiaoyu Song \email{xiaoyu.song@mountsinai.org}
#'
#' @name package
NULL
